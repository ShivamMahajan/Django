from django.shortcuts import render
from . models import  ContactForm
from django.template.loader import get_template
from django.core.mail import EmailMessage
from django.template import Context ,Template
# Create your views here.
# def contact(request):
#     form_class = ContactForm
    
#     return render(request, 'email/contact.html', {
#         'form': form_class,
# #     })
# https://hellowebapp.com/news/tutorial-setting-up-a-contact-form-with-django/
def contact(request):
    form_class = ContactForm

    # new logic!
    if request.method == 'POST':
    	print  "Calling Post Method"
        form = form_class(data=request.POST)

        if form.is_valid():
            contact_name = request.POST.get(
                'contact_name'
            , '')
            contact_email = request.POST.get(
                'contact_email'
            , '')
            form_content = request.POST.get('content', '')

            # Email the profile with the 
            # contact information
            template = get_template('email/contact_template.txt')
            # template= Template("contact_name : {{ contact_name }} contact_email : {{ contact_email }} form_content : {{content }}.")
            context = Context({
                'contact_name': contact_name,
                'contact_email': contact_email,
                'content': form_content,
            })
          
            print ("print COntext :"),context
            content = template.render(context)
            

            email = EmailMessage(
                "New contact form submission",
                content,
                "Your website" +'',
                ['youremail@gmail.com'],
                headers = {'Reply-To': contact_email }
            )
            email.send()
            return render(request, 'email/contact.html')

    return render(request, 'email/contact.html', {
        'form': form_class,
    })
